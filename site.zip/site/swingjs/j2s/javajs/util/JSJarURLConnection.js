(function(){var P$=Clazz.newPackage("javajs.util"),I$=[[0,'swingjs.JSUtil','javajs.util.ZipTools','java.io.ByteArrayInputStream']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSJarURLConnection", null, 'java.net.JarURLConnection');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['$connected']]]

Clazz.newMeth(C$, 'c$$java_net_URL', function (url) {
;C$.superclazz.c$$java_net_URL.apply(this,[url]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getJarFile$', function () {
$I$(1,"notImplemented$S",["JSJarURLConnection does not (yet) implement getJarFile()"]);
return null;
});

Clazz.newMeth(C$, 'connect$', function () {
if (this.url._streamData != null ) return;
var bis=this.getJarFileURL$().openStream$();
var bytes=$I$(2,"getZipFileContentsAsBytes$java_io_BufferedInputStream$SA$I",[bis, Clazz.array(String, -1, [this.getEntryName$()]), 0]);
if (bytes == null ) throw Clazz.new_(Clazz.load('java.util.jar.JarException').c$$S,["Jar entry " + this.getEntryName$() + " was not found in " + this.getJarFileURL$() ]);
this.url._streamData=bytes;
return;
});

Clazz.newMeth(C$, 'getInputStream$', function () {
if (!this.$connected && this.url._streamData == null  ) try {
this.connect$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
return null;
} else {
throw e;
}
}
return Clazz.new_($I$(3,1).c$$BA,[this.url._streamData]);
});

Clazz.newMeth(C$, 'getManifest$', function () {
$I$(1).notImplemented$S(null);
return null;
});

Clazz.newMeth(C$, 'getJarEntry$', function () {
$I$(1).notImplemented$S(null);
return null;
});

Clazz.newMeth(C$, 'getBytesAsync$java_util_function_Function', function (whenDone) {
try {
whenDone.apply$O(this.getInputStream$().readAllBytes$());
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
whenDone.apply$O(null);
} else {
throw e;
}
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-08-12 12:03:19 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
