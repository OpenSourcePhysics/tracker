(function(){var P$=Clazz.newPackage("javajs.api"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "GenericImageEncoder");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-08-13 18:48:33 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
