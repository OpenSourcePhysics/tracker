(function(){var P$=Clazz.newPackage("com.xuggle.xuggler.video"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "IConverter");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'delete$', function () {
});

Clazz.newMeth(C$, 'toPicture$java_awt_image_BufferedImage$J', function (bgrImage, timeStamp) {
return null;
});

Clazz.newMeth(C$, 'getPictureType$', function () {
return null;
});

Clazz.newMeth(C$, 'toImage$com_xuggle_xuggler_IVideoPicture', function (picture) {
return null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-02 13:38:19 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
