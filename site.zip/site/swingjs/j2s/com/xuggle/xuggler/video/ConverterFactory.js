(function(){var P$=Clazz.newPackage("com.xuggle.xuggler.video"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ConverterFactory", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Type',1]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['S',['XUGGLER_BGR_24']]]

Clazz.newMeth(C$, 'createConverter$java_awt_image_BufferedImage$com_xuggle_xuggler_video_ConverterFactory_Type', function (bgrImage, pixelType) {
return null;
}, 1);

Clazz.newMeth(C$, 'findRegisteredConverter$S', function (xugglerBgr24) {
return null;
}, 1);

Clazz.newMeth(C$, 'createConverter$java_awt_image_BufferedImage$com_xuggle_xuggler_IVideoPicture', function (descriptor, picture) {
return null;
}, 1);

Clazz.newMeth(C$, 'createConverter$java_awt_image_BufferedImage$com_xuggle_xuggler_IPixelFormat_Type', function (bgrImage, pixelType) {
return null;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.XUGGLER_BGR_24=null;
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.ConverterFactory, "Type", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getDescriptor$', function () {
return null;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-02 13:38:19 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
