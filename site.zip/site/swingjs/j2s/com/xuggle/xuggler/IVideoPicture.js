(function(){var P$=Clazz.newPackage("com.xuggle.xuggler"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "IVideoPicture");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'setQuality$I', function (i) {
});

Clazz.newMeth(C$, 'getPixelType$', function () {
return null;
});

Clazz.newMeth(C$, 'getHeight$', function () {
return null;
});

Clazz.newMeth(C$, 'getWidth$', function () {
return null;
});

Clazz.newMeth(C$, 'delete$', function () {
});

Clazz.newMeth(C$, 'isComplete$', function () {
return false;
});

Clazz.newMeth(C$, 'make$O$O$O', function (pixelType, width, height) {
return null;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-02 13:38:19 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
