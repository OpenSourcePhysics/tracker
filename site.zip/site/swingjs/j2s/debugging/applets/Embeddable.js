(function(){var P$=Clazz.newPackage("debugging.applets"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Embeddable", null, null, 'debugging.applets.Controllable');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-08-27 14:15:05 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
