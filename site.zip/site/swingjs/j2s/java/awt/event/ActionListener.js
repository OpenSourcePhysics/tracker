(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ActionListener", null, null, 'java.util.EventListener');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-08-27 14:13:36 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
