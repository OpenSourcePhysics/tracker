(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ImageProducer");
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-08-27 14:13:38 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
