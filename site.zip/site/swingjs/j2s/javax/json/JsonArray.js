(function(){var P$=Clazz.newPackage("javax.json"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "JsonArray", null, null, ['javax.json.JsonStructure', 'java.util.List']);

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-08-13 18:48:38 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
