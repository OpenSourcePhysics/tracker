(function(){var P$=Clazz.newPackage("javax.json"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "JsonReader", null, null, 'java.io.Closeable');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-08-13 18:48:39 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
