(function(){var P$=Clazz.newPackage("javax.json.stream"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "JsonGenerator", null, null, ['java.io.Flushable', 'java.io.Closeable']);

C$.$clinit$=2;

C$.$fields$=[[]
,['S',['PRETTY_PRINTING']]]

C$.$static$=function(){C$.$static$=0;
C$.PRETTY_PRINTING="javax.json.stream.JsonGenerator.prettyPrinting";
};
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-08-13 18:48:39 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
