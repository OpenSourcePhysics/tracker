(function(){var P$=Clazz.newPackage("javax.json"),I$=[[0,'javax.json.spi.JsonProvider']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Json");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'createParser$java_io_Reader', function (reader) {
return $I$(1).provider$().createParser$java_io_Reader(reader);
}, 1);

Clazz.newMeth(C$, 'createParser$java_io_InputStream', function ($in) {
return $I$(1).provider$().createParser$java_io_InputStream($in);
}, 1);

Clazz.newMeth(C$, 'createGenerator$java_io_Writer', function (writer) {
return $I$(1).provider$().createGenerator$java_io_Writer(writer);
}, 1);

Clazz.newMeth(C$, 'createGenerator$java_io_OutputStream', function (out) {
return $I$(1).provider$().createGenerator$java_io_OutputStream(out);
}, 1);

Clazz.newMeth(C$, 'createParserFactory$java_util_Map', function (config) {
return $I$(1).provider$().createParserFactory$java_util_Map(config);
}, 1);

Clazz.newMeth(C$, 'createGeneratorFactory$java_util_Map', function (config) {
return $I$(1).provider$().createGeneratorFactory$java_util_Map(config);
}, 1);

Clazz.newMeth(C$, 'createWriter$java_io_Writer', function (writer) {
return $I$(1).provider$().createWriter$java_io_Writer(writer);
}, 1);

Clazz.newMeth(C$, 'createWriter$java_io_OutputStream', function (out) {
return $I$(1).provider$().createWriter$java_io_OutputStream(out);
}, 1);

Clazz.newMeth(C$, 'createReader$java_io_Reader', function (reader) {
return $I$(1).provider$().createReader$java_io_Reader(reader);
}, 1);

Clazz.newMeth(C$, 'createReader$java_io_InputStream', function ($in) {
return $I$(1).provider$().createReader$java_io_InputStream($in);
}, 1);

Clazz.newMeth(C$, 'createReaderFactory$java_util_Map', function (config) {
return $I$(1).provider$().createReaderFactory$java_util_Map(config);
}, 1);

Clazz.newMeth(C$, 'createWriterFactory$java_util_Map', function (config) {
return $I$(1).provider$().createWriterFactory$java_util_Map(config);
}, 1);

Clazz.newMeth(C$, 'createArrayBuilder$', function () {
return $I$(1).provider$().createArrayBuilder$();
}, 1);

Clazz.newMeth(C$, 'createObjectBuilder$', function () {
return $I$(1).provider$().createObjectBuilder$();
}, 1);

Clazz.newMeth(C$, 'createBuilderFactory$java_util_Map', function (config) {
return $I$(1).provider$().createBuilderFactory$java_util_Map(config);
}, 1);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-08-13 18:48:38 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
