(function(){var P$=Clazz.newPackage("javax.annotation"),I$=[];
/*@*/var C$=Clazz.newClass(P$, "WillNotClose", null, null, 'java.lang.annotation.Annotation');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
C$.prototype.annotationType = function() { return this.getClass$() };
C$.$getMembers$ = function() {var a=[];
return a}
Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-08-13 18:48:36 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
