(function(){var P$=Clazz.newPackage("javax.swing.border"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Border");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-08-13 18:48:54 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
