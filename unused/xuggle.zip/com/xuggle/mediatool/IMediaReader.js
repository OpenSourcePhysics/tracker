(function(){var P$=Clazz.newPackage("com.xuggle.mediatool"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "IMediaReader");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'setBufferedImageTypeToGenerate$I', function (type3byteBgr) {
});

Clazz.newMeth(C$, 'readPacket$', function () {
return null;
});

Clazz.newMeth(C$, 'addListener$com_xuggle_mediatool_MediaToolAdapter', function (tool) {
});

Clazz.newMeth(C$, 'close$', function () {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 11:46:16 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
