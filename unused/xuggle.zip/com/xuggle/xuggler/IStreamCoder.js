(function(){var P$=Clazz.newPackage("com.xuggle.xuggler"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "IStreamCoder");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'setNumPicturesInGroupOfPictures$I', function (i) {
});

Clazz.newMeth(C$, 'setPixelType$com_xuggle_xuggler_IPixelFormat_Type', function (pixelType) {
});

Clazz.newMeth(C$, 'setBitRate$I', function (i) {
});

Clazz.newMeth(C$, 'setCodec$com_xuggle_xuggler_ICodec', function (codec) {
});

Clazz.newMeth(C$, 'setHeight$I', function (height) {
});

Clazz.newMeth(C$, 'setWidth$I', function (width) {
});

Clazz.newMeth(C$, 'setFrameRate$com_xuggle_xuggler_IRational', function (frameRate) {
});

Clazz.newMeth(C$, 'setTimeBase$com_xuggle_xuggler_IRational', function (make) {
});

Clazz.newMeth(C$, 'open$', function () {
return 0;
});

Clazz.newMeth(C$, 'encodeVideo$com_xuggle_xuggler_IPacket$com_xuggle_xuggler_IVideoPicture$I', function (packet, picture, i) {
return 0;
});

Clazz.newMeth(C$, 'close$', function () {
});

Clazz.newMeth(C$, 'getHeight$', function () {
return null;
});

Clazz.newMeth(C$, 'delete$', function () {
});

Clazz.newMeth(C$, 'decodeVideo$com_xuggle_xuggler_IVideoPicture$com_xuggle_xuggler_IPacket$I', function (tempPicture, tempPacket, offset) {
return 0;
});

Clazz.newMeth(C$, 'getWidth$', function () {
return null;
});

Clazz.newMeth(C$, 'getPixelType$', function () {
return null;
});

Clazz.newMeth(C$, 'getCodecType$', function () {
return null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 11:46:17 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
