(function(){var P$=Clazz.newPackage("com.xuggle.xuggler"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "IVideoResampler");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getOutputPixelFormat$', function () {
return null;
});

Clazz.newMeth(C$, 'resample$com_xuggle_xuggler_IVideoPicture$com_xuggle_xuggler_IVideoPicture', function (newPic, picture) {
return 0;
});

Clazz.newMeth(C$, 'make$O$O$com_xuggle_xuggler_IPixelFormat_Type$O$O$O', function (width, height, bgr24, width2, height2, pixelType) {
return null;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 11:46:17 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
