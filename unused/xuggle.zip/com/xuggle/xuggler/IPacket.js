(function(){var P$=Clazz.newPackage("com.xuggle.xuggler");
/*c*/var C$=Clazz.newClass(P$, "IPacket");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'make$', function () {
return null;
}, 1);

Clazz.newMeth(C$, 'isComplete$', function () {
return false;
});

Clazz.newMeth(C$, 'getSize$', function () {
return 0;
});

Clazz.newMeth(C$, 'delete$', function () {
});

Clazz.newMeth(C$, 'getTimeStamp$', function () {
return 0;
});

Clazz.newMeth(C$, 'isKeyPacket$', function () {
return false;
});

Clazz.newMeth(C$, 'getStreamIndex$', function () {
return 0;
});

Clazz.newMeth(C$, 'getTimeBase$', function () {
return null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 11:46:17 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
