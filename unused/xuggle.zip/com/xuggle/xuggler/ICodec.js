(function(){var P$=Clazz.newPackage("com.xuggle.xuggler"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ICodec", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['ID',1],['Type',25]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'guessEncodingCodec$com_xuggle_xuggler_IContainerFormat$O$S$O$com_xuggle_xuggler_ICodec_Type', function (format, object, typicalName, object2, codecTypeVideo) {
return null;
}, 1);

Clazz.newMeth(C$, 'findEncodingCodec$com_xuggle_xuggler_ICodec_ID', function (id) {
return null;
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.ICodec, "ID", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$);
})()
;
(function(){/*e*/var C$=Clazz.newClass(P$.ICodec, "Type", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "CODEC_TYPE_VIDEO", 0, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 11:46:17 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
