(function(){var P$=Clazz.newPackage("org.opensourcephysics.controls"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ConsoleLevel", null, 'java.util.logging.Level');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['OUT_CONSOLE','org.opensourcephysics.controls.ConsoleLevel','+ERR_CONSOLE']]]

Clazz.newMeth(C$, 'c$$S$I', function (name, value) {
;C$.superclazz.c$$S$I.apply(this,[name, value]);C$.$init$.apply(this);
}, 1);

C$.$static$=function(){C$.$static$=0;
{
C$.OUT_CONSOLE=Clazz.new_(C$.c$$S$I,["OUT_CONSOLE", 750]);
C$.ERR_CONSOLE=Clazz.new_(C$.c$$S$I,["ERR_CONSOLE", 760]);
};
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 10:48:27 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
