(function(){var P$=Clazz.newPackage("org.opensourcephysics.controls"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "MainFrame");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 10:48:27 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
