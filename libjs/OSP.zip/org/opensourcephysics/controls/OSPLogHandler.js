(function(){var P$=Clazz.newPackage("org.opensourcephysics.controls"),I$=[[0,'java.awt.Color','java.util.logging.Level','org.opensourcephysics.controls.ConsoleLevel','java.util.logging.LogRecord','org.opensourcephysics.display.OSPRuntime','org.opensourcephysics.js.JSUtil','java.io.PrintStream','org.opensourcephysics.controls.LoggerOutputStream','org.opensourcephysics.controls.MessageFrame','org.opensourcephysics.controls.OSPLog','java.awt.EventQueue','java.io.BufferedWriter','java.io.FileWriter','javax.swing.JOptionPane','org.opensourcephysics.controls.ControlsRes','org.opensourcephysics.controls.XML','javax.swing.JPanel','java.awt.BorderLayout','java.awt.Dimension','java.awt.RenderingHints','javax.swing.JTextPane','javax.swing.JScrollPane','javax.swing.text.StyleContext','javax.swing.text.StyleConstants','org.opensourcephysics.tools.FontSizer','java.awt.event.MouseAdapter','java.util.logging.Logger','org.opensourcephysics.controls.OSPLogHandler','org.opensourcephysics.controls.ConsoleFormatter','java.util.logging.FileHandler','java.util.logging.XMLFormatter','javax.swing.JPopupMenu','javax.swing.JMenu','javax.swing.ButtonGroup','javax.swing.JRadioButtonMenuItem','javax.swing.AbstractAction','javax.swing.JMenuBar','javax.swing.JCheckBoxMenuItem','javax.swing.JFileChooser','java.io.File','java.io.BufferedReader','java.io.FileReader','StringBuffer','Throwable','java.io.StringWriter','java.io.PrintWriter','org.opensourcephysics.controls.XMLControlElement']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "OSPLogHandler", null, 'java.util.logging.Handler');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['logPane','javax.swing.JTextPane','ospLog','org.opensourcephysics.controls.OSPLog']]]

Clazz.newMeth(C$, 'c$$javax_swing_JTextPane$org_opensourcephysics_controls_OSPLog', function (textPane, log) {
Clazz.super_(C$, this);
this.logPane=textPane;
this.ospLog=log;
}, 1);

Clazz.newMeth(C$, 'publish$java_util_logging_LogRecord', function (record) {
if (!this.isLoggable$java_util_logging_LogRecord(record)) {
return;
}var msg=this.getFormatter$().format$java_util_logging_LogRecord(record);
var style=$I$(10).green;
var val=record.getLevel$().intValue$();
if (val == $I$(3).ERR_CONSOLE.intValue$()) {
if (msg.indexOf$S("OutOfMemory") > -1) this.ospLog.firePropertyChange$S$J$J("error", -1, 1);
if (!$I$(10).logConsole) return;
style=$I$(10).magenta;
} else if (val == $I$(3).OUT_CONSOLE.intValue$()) {
if (msg.indexOf$S("ERROR org.ffmpeg") > -1) this.ospLog.firePropertyChange$S$O$O("ffmpeg_error", null, msg);
 else if (msg.indexOf$S("JNILibraryLoader") > -1) {
this.ospLog.firePropertyChange$S$O$O("xuggle_error", null, msg);
}if (!$I$(10).logConsole) return;
style=$I$(10).gray;
} else if (val >= $I$(2).WARNING.intValue$()) {
style=$I$(10).red;
} else if (val >= $I$(2).INFO.intValue$()) {
style=$I$(10).black;
} else if (val >= $I$(2).CONFIG.intValue$()) {
style=$I$(10).green;
} else if (val >= $I$(2).FINEST.intValue$()) {
style=$I$(10).blue;
}try {
var doc=this.logPane.getDocument$();
doc.insertString$I$S$javax_swing_text_AttributeSet(doc.getLength$(), msg + '\n', style);
var rect=this.logPane.getBounds$();
rect.y=rect.height;
this.logPane.scrollRectToVisible$java_awt_Rectangle(rect);
} catch (ex) {
if (Clazz.exceptionOf(ex,"javax.swing.text.BadLocationException")){
System.err.println$O(ex);
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'flush$', function () {
});

Clazz.newMeth(C$, 'close$', function () {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 10:48:27 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
