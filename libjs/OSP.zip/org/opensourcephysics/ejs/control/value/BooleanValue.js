(function(){var P$=Clazz.newPackage("org.opensourcephysics.ejs.control.value"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "BooleanValue", null, 'org.opensourcephysics.ejs.control.value.Value');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['value']]]

Clazz.newMeth(C$, 'c$$Z', function (_val) {
Clazz.super_(C$, this);
this.value=_val;
}, 1);

Clazz.newMeth(C$, 'getBoolean$', function () {
return this.value;
});

Clazz.newMeth(C$, 'getInteger$', function () {
if (this.value) {
return 1;
}return 0;
});

Clazz.newMeth(C$, 'getDouble$', function () {
if (this.value) {
return 1.0;
}return 0.0;
});

Clazz.newMeth(C$, 'getString$', function () {
if (this.value) {
return "true";
}return "false";
});

Clazz.newMeth(C$, 'getObject$', function () {
return null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 10:48:31 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
