(function(){var P$=Clazz.newPackage("org.opensourcephysics.ejs.control.value"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ObjectValue", null, 'org.opensourcephysics.ejs.control.value.Value');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['value','java.lang.Object']]]

Clazz.newMeth(C$, 'c$$O', function (_val) {
Clazz.super_(C$, this);
this.value=_val;
}, 1);

Clazz.newMeth(C$, 'getBoolean$', function () {
if (this.value == null ) {
return false;
}return this.value.toString().equals$O("true");
});

Clazz.newMeth(C$, 'getInteger$', function () {
return (Math.round(this.getDouble$())|0);
});

Clazz.newMeth(C$, 'getDouble$', function () {
try {
return Double.valueOf$S(this.value.toString()).doubleValue$();
} catch (exc) {
if (Clazz.exceptionOf(exc,"NumberFormatException")){
return 0.0;
} else {
throw exc;
}
}
});

Clazz.newMeth(C$, 'getString$', function () {
if (this.value == null ) {
return null;
}return this.value.toString();
});

Clazz.newMeth(C$, 'getObject$', function () {
return this.value;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 10:48:31 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
