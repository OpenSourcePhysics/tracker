(function(){var P$=Clazz.newPackage("org.opensourcephysics.numerics"),p$1={},I$=[[0,'java.util.Hashtable','java.util.Vector','StringBuffer']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SuryonoParser", null, 'org.opensourcephysics.numerics.MathExpParser');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.$function="";
this.postfix_code="";
this.valid=false;
this.ISBOOLEAN=false;
this.INRELATION=false;
this.refvalue=null;
this.stack=Clazz.array(Double.TYPE, [50]);
this.references=null;
this.refnames=null;
this.funcname=Clazz.array(String, -1, ["sin", "cos", "tan", "ln", "log", "abs", "int", "frac", "asin", "acos", "atan", "sinh", "cosh", "tanh", "asinh", "acosh", "atanh", "ceil", "floor", "round", "exp", "sqr", "sqrt", "sign", "step", "random"]);
this.extfunc=Clazz.array(String, -1, ["min", "max", "mod", "atan2"]);
this.appendVariables=false;
},1);

C$.$fields$=[['Z',['valid','ISBOOLEAN','INRELATION','radian','isNaN','appendVariables'],'C',['character'],'I',['var_count','error','position','start','num','numberindex'],'S',['$function','postfix_code'],'O',['var_name','String[]','var_value','double[]','+number','+refvalue','+stack','references','java.util.Hashtable','refnames','java.util.Vector','funcname','String[]','+extfunc']]
,['D',['LOG10']]]

Clazz.newMeth(C$, 'c$$S$S', function (f, v) {
C$.c$$I.apply(this, [1]);
this.defineVariable$I$S(1, v);
this.define$S(f);
this.parse$();
if (this.getErrorCode$() != 0) {
var msg="Error in function string: " + f;
msg=msg + '\n' + "Error: " + this.getErrorString$() ;
msg=msg + '\n' + "Position: " + this.getErrorPosition$() ;
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$S,[msg]);
}}, 1);

Clazz.newMeth(C$, 'c$$S$S$S', function (f, v1, v2) {
C$.c$$I.apply(this, [2]);
this.defineVariable$I$S(1, v1);
this.defineVariable$I$S(2, v2);
this.define$S(f);
this.parse$();
if (this.getErrorCode$() != 0) {
var msg="Error in function string: " + f;
msg=msg + '\n' + "Error: " + this.getErrorString$() ;
msg=msg + '\n' + "Position: " + this.getErrorPosition$() ;
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$S,[msg]);
}}, 1);

Clazz.newMeth(C$, 'c$$S$SA', function (f, v) {
C$.c$$I.apply(this, [v.length]);
for (var i=0; i < v.length; i++) {
this.defineVariable$I$S(i + 1, v[i]);
}
this.define$S(f);
this.parse$();
if (this.getErrorCode$() != 0) {
var msg="Error in function string: " + f;
msg=msg + '\n' + "Error: " + this.getErrorString$() ;
msg=msg + '\n' + "Position: " + this.getErrorPosition$() ;
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$S,[msg]);
}}, 1);

Clazz.newMeth(C$, 'c$$I', function (variablecount) {
Clazz.super_(C$, this);
this.var_count=variablecount;
this.references=Clazz.new_($I$(1,1));
this.refnames=Clazz.new_($I$(2,1));
this.radian=true;
this.var_name=Clazz.array(String, [variablecount]);
this.var_value=Clazz.array(Double.TYPE, [variablecount]);
this.number=Clazz.array(Double.TYPE, [200]);
}, 1);

Clazz.newMeth(C$, 'setToZero$', function () {
try {
this.setFunction$S("0");
} catch (ex) {
if (Clazz.exceptionOf(ex,"org.opensourcephysics.numerics.ParserException")){
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'useRadian$', function () {
this.radian=true;
});

Clazz.newMeth(C$, 'useDegree$', function () {
this.radian=false;
});

Clazz.newMeth(C$, 'removeEscapeCharacter$S', function (str) {
if ((str == null ) || (str.length$() < 1) ) {
return str;
}var sb=Clazz.new_([str.length$()],$I$(3,1).c$$I);
for (var i=0; i < str.length$(); i++) {
if (str.charAt$I(i) != "\\") {
sb.append$C(str.charAt$I(i));
}}
return sb.toString();
}, p$1);

Clazz.newMeth(C$, 'defineVariable$I$S', function (index, name) {
if (index > this.var_count) {
return;
}this.var_name[index - 1]=name;
});

Clazz.newMeth(C$, 'setVariable$I$D', function (index, value) {
if (index > this.var_count) {
return;
}this.var_value[index - 1]=value;
});

Clazz.newMeth(C$, 'setVariable$S$D', function (name, value) {
for (var i=0; i < this.var_count; i++) {
if (this.var_name[i].equals$O(name)) {
this.var_value[i]=value;
break;
}}
});

Clazz.newMeth(C$, 'define$S', function (definition) {
this.$function=definition;
this.$function.toLowerCase$();
this.$function=p$1.removeEscapeCharacter$S.apply(this, [this.$function]);
this.valid=false;
});

Clazz.newMeth(C$, 'parse$S', function ($function) {
this.define$S($function);
this.parse$();
if (this.getErrorCode$() != 0) {
var msg="Error in function string: " + $function;
msg=msg + '\n' + "Error: " + this.getErrorString$() ;
msg=msg + '\n' + "Position: " + this.getErrorPosition$() ;
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$S,[msg]);
}});

Clazz.newMeth(C$, 'parseUnknown$S', function ($function) {
this.var_name=Clazz.array(String, [0]);
this.var_value=Clazz.array(Double.TYPE, [0]);
this.var_count=0;
this.appendVariables=true;
this.define$S($function);
this.parse$();
if (this.getErrorCode$() != 0) {
var msg="Error in function string: " + $function;
msg=msg + '\n' + "Error: " + this.getErrorString$() ;
msg=msg + '\n' + "Position: " + this.getErrorPosition$() ;
this.appendVariables=false;
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$S,[msg]);
}this.appendVariables=false;
return this.var_name;
});

Clazz.newMeth(C$, 'getVariableNames$', function () {
return this.var_name;
});

Clazz.newMeth(C$, 'getFunctionNames$', function () {
var len=this.funcname.length;
var names=Clazz.array(String, [len + this.extfunc.length]);
System.arraycopy$O$I$O$I$I(this.funcname, 0, names, 0, len);
System.arraycopy$O$I$O$I$I(this.extfunc, 0, names, len, this.extfunc.length);
return names;
});

Clazz.newMeth(C$, 'parse$', function () {
var allFunction= String.instantialize(this.$function);
var orgFunction= String.instantialize(this.$function);
var index;
if (this.valid) {
return;
}this.num=0;
this.error=0;
this.references.clear$();
this.refnames.removeAllElements$();
while ((index=allFunction.lastIndexOf$S(";")) != -1){
this.$function=allFunction.substring$I(index + 1) + ')';
allFunction=allFunction.substring$I$I(0, index++);
var refname=null;
var separator=this.$function.indexOf$S(":");
if (separator == -1) {
this.error=14;
for (this.position=0; this.position < this.$function.length$(); this.position++) {
if (this.$function.charAt$I(this.position) != " ") {
break;
}}
this.position++;
} else {
refname=this.$function.substring$I$I(0, separator);
this.$function=this.$function.substring$I(separator + 1);
refname=refname.trim$();
if (refname.equals$O("")) {
this.error=15;
this.position=1;
} else {
index+=++separator;
p$1.parseSubFunction.apply(this, []);
}}if (this.error != 0) {
this.position+=index;
break;
}this.references.put$O$O(refname, this.postfix_code);
this.refnames.addElement$O(refname);
}
if (this.error == 0) {
this.$function=allFunction + ')';
p$1.parseSubFunction.apply(this, []);
}this.$function=orgFunction;
this.valid=(this.error == 0);
});

Clazz.newMeth(C$, 'evaluate$D$D', function (x, y) {
if (this.var_count != 2) {
return 0;
}this.var_value[0]=x;
this.var_value[1]=y;
return this.evaluate$();
});

Clazz.newMeth(C$, 'evaluate$D$D$D', function (x, y, z) {
if (this.var_count != 3) {
return 0;
}this.var_value[0]=x;
this.var_value[1]=y;
this.var_value[2]=z;
return this.evaluate$();
});

Clazz.newMeth(C$, 'evaluate$D', function (x) {
if (this.var_count != 1) {
return 0;
}this.var_value[0]=x;
return this.evaluate$();
});

Clazz.newMeth(C$, 'evaluate$DA', function (v) {
if (this.var_value.length != v.length) {
System.out.println$S("JEParser Error: incorrect number of variables.");
return 0;
}System.arraycopy$O$I$O$I$I(v, 0, this.var_value, 0, v.length);
return this.evaluate$();
});

Clazz.newMeth(C$, 'evaluate$', function () {
var size=this.refnames.size$();
var result;
if (!this.valid) {
this.error=3;
return 0;
}this.error=0;
this.numberindex=0;
if (size != 0) {
var orgPFC=this.postfix_code;
this.refvalue=Clazz.array(Double.TYPE, [size]);
for (var i=0; i < this.refnames.size$(); i++) {
var name=this.refnames.elementAt$I(i);
this.postfix_code=this.references.get$O(name);
result=p$1.evaluateSubFunction.apply(this, []);
if (this.error != 0) {
this.postfix_code=orgPFC;
this.refvalue=null;
return result;
}this.refvalue[i]=result;
}
this.postfix_code=orgPFC;
}result=p$1.evaluateSubFunction.apply(this, []);
this.refvalue=null;
this.isNaN=Double.isNaN$D(result);
if (this.isNaN) {
result=0.0;
}return result;
});

Clazz.newMeth(C$, 'evaluatedToNaN$', function () {
return this.isNaN;
});

Clazz.newMeth(C$, 'getErrorCode$', function () {
return this.error;
});

Clazz.newMeth(C$, 'getErrorString$', function () {
return C$.toErrorString$I(this.error);
});

Clazz.newMeth(C$, 'getErrorPosition$', function () {
return this.position;
});

Clazz.newMeth(C$, 'toErrorString$I', function (errorcode) {
var s="";
switch (errorcode) {
case 0:
s="no error";
break;
case 1:
s="syntax error";
break;
case 2:
s="parenthesis expected";
break;
case 3:
s="uncompiled function";
break;
case 4:
s="expression expected";
break;
case 5:
s="unknown identifier";
break;
case 6:
s="operator expected";
break;
case 7:
s="parentheses not match";
break;
case 8:
s="internal code damaged";
break;
case 9:
s="execution stack overflow";
break;
case 10:
s="too many constants";
break;
case 11:
s="comma expected";
break;
case 12:
s="invalid operand type";
break;
case 13:
s="invalid operator";
break;
case 14:
s="bad reference definition (: expected)";
break;
case 15:
s="reference name expected";
break;
}
return s;
}, 1);

Clazz.newMeth(C$, 'getFunction$', function () {
return this.$function;
});

Clazz.newMeth(C$, 'setFunction$S', function (funcStr) {
this.$function=funcStr;
this.define$S(this.$function);
this.parse$();
if (this.error != 0) {
var msg="Error in function string: " + funcStr;
msg=msg + '\n' + "Error: " + C$.toErrorString$I(this.error) ;
msg=msg + '\n' + "Position: " + this.getErrorPosition$() ;
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$S,[msg]);
}});

Clazz.newMeth(C$, 'setFunction$S$SA', function (funcStr, vars) {
this.$function=funcStr;
if (vars.length != this.var_count) {
this.var_count=vars.length;
this.references.clear$();
this.refnames.clear$();
this.var_name=Clazz.array(String, [this.var_count]);
this.var_value=Clazz.array(Double.TYPE, [this.var_count]);
}for (var i=0; i < vars.length; i++) {
this.defineVariable$I$S(i + 1, vars[i]);
}
this.define$S(this.$function);
this.parse$();
if (this.error != 0) {
var msg="Error in function string: " + funcStr;
msg=msg + '\n' + "Error: " + C$.toErrorString$I(this.error) ;
msg=msg + '\n' + "Position: " + this.getErrorPosition$() ;
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$S,[msg]);
}});

Clazz.newMeth(C$, 'skipSpaces', function () {
try {
while (this.$function.charAt$I(this.position - 1) == " "){
this.position++;
}
this.character=this.$function.charAt$I(this.position - 1);
} catch (e) {
if (Clazz.exceptionOf(e,"StringIndexOutOfBoundsException")){
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[7]);
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'getNextCharacter', function () {
this.position++;
try {
this.character=this.$function.charAt$I(this.position - 1);
} catch (e) {
if (Clazz.exceptionOf(e,"StringIndexOutOfBoundsException")){
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[7]);
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'addCode$C', function (code) {
this.postfix_code += code;
}, p$1);

Clazz.newMeth(C$, 'scanNumber', function () {
var numstr="";
var value;
if (this.num == 200) {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[10]);
}if (this.character != ".") {
do {
numstr += this.character;
p$1.getNextCharacter.apply(this, []);
} while ((this.character >= "0") && (this.character <= "9") );
} else {
numstr += "0";
}if (this.character == ".") {
do {
numstr += this.character;
p$1.getNextCharacter.apply(this, []);
} while ((this.character >= "0") && (this.character <= "9") );
}if ((this.character == "e") || (this.character == "E") ) {
numstr += this.character;
p$1.getNextCharacter.apply(this, []);
if ((this.character == "+") || (this.character == "-") ) {
numstr += this.character;
p$1.getNextCharacter.apply(this, []);
}while ((this.character >= "0") && (this.character <= "9") ){
numstr += this.character;
p$1.getNextCharacter.apply(this, []);
}
}try {
value=Double.valueOf$S(numstr).doubleValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"NumberFormatException")){
this.position=this.start;
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[1]);
} else {
throw e;
}
}
this.number[this.num++]=value;
p$1.addCode$C.apply(this, ["\u00ff"]);
}, p$1);

Clazz.newMeth(C$, 'scanNonNumeric', function () {
var stream="";
if ((this.character == "*") || (this.character == "/") || (this.character == "^") || (this.character == ")") || (this.character == ",") || (this.character == "<") || (this.character == ">") || (this.character == "=") || (this.character == "&") || (this.character == "|")  ) {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[1]);
}do {
stream += this.character;
p$1.getNextCharacter.apply(this, []);
} while (!((this.character == " ") || (this.character == "+") || (this.character == "-") || (this.character == "*") || (this.character == "/") || (this.character == "^") || (this.character == "(") || (this.character == ")") || (this.character == ",") || (this.character == "<") || (this.character == ">") || (this.character == "=") || (this.character == "&") || (this.character == "|")  ));
if (stream.equals$O("pi")) {
p$1.addCode$C.apply(this, ["\u00fd"]);
return;
} else if (stream.equals$O("e")) {
p$1.addCode$C.apply(this, ["\u00fe"]);
return;
}if (stream.equals$O("if")) {
p$1.skipSpaces.apply(this, []);
if (this.character != "(") {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[2]);
}p$1.scanAndParse.apply(this, []);
if (this.character != ",") {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[11]);
}p$1.addCode$C.apply(this, ["\u0008"]);
var savecode= String.instantialize(this.postfix_code);
this.postfix_code="";
p$1.scanAndParse.apply(this, []);
if (this.character != ",") {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[11]);
}p$1.addCode$C.apply(this, ["\u0001"]);
savecode += String.fromCharCode((this.postfix_code.length$() + 2));
savecode += this.postfix_code;
this.postfix_code="";
p$1.scanAndParse.apply(this, []);
if (this.character != ")") {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[2]);
}savecode += String.fromCharCode((this.postfix_code.length$() + 1));
savecode += this.postfix_code;
this.postfix_code= String.instantialize(savecode);
p$1.getNextCharacter.apply(this, []);
return;
}for (var i=0; i < 26; i++) {
if (stream.equals$O(this.funcname[i])) {
p$1.skipSpaces.apply(this, []);
if (this.character != "(") {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[2]);
}p$1.scanAndParse.apply(this, []);
if (this.character != ")") {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[2]);
}p$1.getNextCharacter.apply(this, []);
p$1.addCode$C.apply(this, [String.fromCharCode((i + 1000))]);
return;
}}
for (var i=0; i < 4; i++) {
if (stream.equals$O(this.extfunc[i])) {
p$1.skipSpaces.apply(this, []);
if (this.character != "(") {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[2]);
}p$1.scanAndParse.apply(this, []);
if (this.character != ",") {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[11]);
}var savecode= String.instantialize(this.postfix_code);
this.postfix_code="";
p$1.scanAndParse.apply(this, []);
if (this.character != ")") {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[2]);
}p$1.getNextCharacter.apply(this, []);
savecode += this.postfix_code;
this.postfix_code= String.instantialize(savecode);
p$1.addCode$C.apply(this, [String.fromCharCode((i + 1026))]);
return;
}}
for (var i=0; i < this.var_count; i++) {
if (stream.equals$O(this.var_name[i])) {
p$1.addCode$C.apply(this, [String.fromCharCode((i + 2000))]);
return;
}}
var index=this.refnames.indexOf$O(stream);
if (index != -1) {
p$1.addCode$C.apply(this, [String.fromCharCode((index + 3000))]);
return;
}if (this.appendVariables && p$1.append$S.apply(this, [stream]) ) {
return;
}this.position=this.start;
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[5]);
}, p$1);

Clazz.newMeth(C$, 'append$S', function (stream) {
var var_name2=Clazz.array(String, [this.var_count + 1]);
var var_value2=Clazz.array(Double.TYPE, [this.var_count + 1]);
System.arraycopy$O$I$O$I$I(this.var_name, 0, var_name2, 0, this.var_count);
System.arraycopy$O$I$O$I$I(this.var_value, 0, var_value2, 0, this.var_count);
var_name2[this.var_count]=stream;
this.var_name=var_name2;
this.var_value=var_value2;
this.var_count++;
for (var i=0; i < this.var_count; i++) {
if (stream.equals$O(this.var_name[i])) {
p$1.addCode$C.apply(this, [String.fromCharCode((i + 2000))]);
return true;
}}
return false;
}, p$1);

Clazz.newMeth(C$, 'getIdentifier', function () {
var negate=false;
p$1.getNextCharacter.apply(this, []);
p$1.skipSpaces.apply(this, []);
if (this.character == "!") {
p$1.getNextCharacter.apply(this, []);
p$1.skipSpaces.apply(this, []);
if (this.character != "(") {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[2]);
}p$1.scanAndParse.apply(this, []);
if (this.character != ")") {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[2]);
}if (!this.ISBOOLEAN) {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[12]);
}p$1.addCode$C.apply(this, ["\f"]);
p$1.getNextCharacter.apply(this, []);
return false;
}this.ISBOOLEAN=false;
while ((this.character == "+") || (this.character == "-") ){
if (this.character == "-") {
negate=!negate;
}p$1.getNextCharacter.apply(this, []);
p$1.skipSpaces.apply(this, []);
}
this.start=this.position;
if (((this.character >= "0") && (this.character <= "9") ) || (this.character == ".") ) {
p$1.scanNumber.apply(this, []);
} else if (this.character == "(") {
p$1.scanAndParse.apply(this, []);
p$1.getNextCharacter.apply(this, []);
} else {
p$1.scanNonNumeric.apply(this, []);
}p$1.skipSpaces.apply(this, []);
return (negate);
}, p$1);

Clazz.newMeth(C$, 'arithmeticLevel3', function () {
var negate;
if (this.ISBOOLEAN) {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[12]);
}negate=p$1.getIdentifier.apply(this, []);
if (this.ISBOOLEAN) {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[12]);
}if (this.character == "^") {
p$1.arithmeticLevel3.apply(this, []);
}p$1.addCode$C.apply(this, ["^"]);
if (negate) {
p$1.addCode$C.apply(this, ["_"]);
}}, p$1);

Clazz.newMeth(C$, 'arithmeticLevel2', function () {
var negate;
if (this.ISBOOLEAN) {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[12]);
}do {
var operator=this.character;
negate=p$1.getIdentifier.apply(this, []);
if (this.ISBOOLEAN) {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[12]);
}if (this.character == "^") {
p$1.arithmeticLevel3.apply(this, []);
}if (negate) {
p$1.addCode$C.apply(this, ["_"]);
}p$1.addCode$C.apply(this, [operator]);
} while ((this.character == "*") || (this.character == "/") );
}, p$1);

Clazz.newMeth(C$, 'arithmeticLevel1', function () {
var negate;
if (this.ISBOOLEAN) {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[12]);
}do {
var operator=this.character;
negate=p$1.getIdentifier.apply(this, []);
if (this.ISBOOLEAN) {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[12]);
}if (this.character == "^") {
p$1.arithmeticLevel3.apply(this, []);
if (negate) {
p$1.addCode$C.apply(this, ["_"]);
}} else if ((this.character == "*") || (this.character == "/") ) {
if (negate) {
p$1.addCode$C.apply(this, ["_"]);
}p$1.arithmeticLevel2.apply(this, []);
}p$1.addCode$C.apply(this, [operator]);
} while ((this.character == "+") || (this.character == "-") );
}, p$1);

Clazz.newMeth(C$, 'relationLevel', function () {
var code="\u0000";
if (this.INRELATION) {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[13]);
}this.INRELATION=true;
if (this.ISBOOLEAN) {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[12]);
}switch (this.character.$c()) {
case 61:
code="\u0007";
break;
case 60:
code="\u0002";
p$1.getNextCharacter.apply(this, []);
if (this.character == ">") {
code="\u0006";
} else if (this.character == "=") {
code="\u0004";
} else {
this.position--;
}break;
case 62:
code="\u0003";
p$1.getNextCharacter.apply(this, []);
if (this.character == "=") {
code="\u0005";
} else {
this.position--;
}break;
}
p$1.scanAndParse.apply(this, []);
this.INRELATION=false;
if (this.ISBOOLEAN) {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[12]);
}p$1.addCode$C.apply(this, [code]);
this.ISBOOLEAN=true;
}, p$1);

Clazz.newMeth(C$, 'booleanLevel', function () {
if (!this.ISBOOLEAN) {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[12]);
}var operator=this.character;
p$1.scanAndParse.apply(this, []);
if (!this.ISBOOLEAN) {
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[12]);
}switch (operator.$c()) {
case 38:
p$1.addCode$C.apply(this, ["\n"]);
break;
case 124:
p$1.addCode$C.apply(this, ["\u000b"]);
break;
}
}, p$1);

Clazz.newMeth(C$, 'scanAndParse', function () {
var negate;
negate=p$1.getIdentifier.apply(this, []);
if ((this.character != "^") && (negate) ) {
p$1.addCode$C.apply(this, ["_"]);
}do {
switch (this.character.$c()) {
case 43:
case 45:
p$1.arithmeticLevel1.apply(this, []);
break;
case 42:
case 47:
p$1.arithmeticLevel2.apply(this, []);
break;
case 94:
p$1.arithmeticLevel3.apply(this, []);
if (negate) {
p$1.addCode$C.apply(this, ["_"]);
}break;
case 44:
case 41:
return;
case 61:
case 60:
case 62:
p$1.relationLevel.apply(this, []);
break;
case 38:
case 124:
p$1.booleanLevel.apply(this, []);
break;
default:
throw Clazz.new_(Clazz.load('org.opensourcephysics.numerics.ParserException').c$$I,[6]);
}
} while (true);
}, p$1);

Clazz.newMeth(C$, 'parseSubFunction', function () {
this.position=0;
this.postfix_code="";
this.INRELATION=false;
this.ISBOOLEAN=false;
try {
p$1.scanAndParse.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"org.opensourcephysics.numerics.ParserException")){
this.error=e.getErrorCode$();
if ((this.error == 1) && (this.postfix_code === "" ) ) {
this.error=4;
}} else {
throw e;
}
}
if ((this.error == 0) && (this.position != this.$function.length$()) ) {
this.error=7;
}}, p$1);

Clazz.newMeth(C$, 'builtInFunction$I$D', function ($function, parameter) {
switch ($function) {
case 0:
if (this.radian) {
return Math.sin(parameter);
}return Math.sin(parameter * 0.017453292519943295);
case 1:
if (this.radian) {
return Math.cos(parameter);
}return Math.cos(parameter * 0.017453292519943295);
case 2:
if (this.radian) {
return Math.tan(parameter);
}return Math.tan(parameter * 0.017453292519943295);
case 3:
return Math.log(parameter);
case 4:
return Math.log(parameter) / C$.LOG10;
case 5:
return Math.abs(parameter);
case 6:
return Math.rint(parameter);
case 7:
return parameter - Math.rint(parameter);
case 8:
if (this.radian) {
return Math.asin(parameter);
}return Math.asin(parameter) / 0.017453292519943295;
case 9:
if (this.radian) {
return Math.acos(parameter);
}return Math.acos(parameter) / 0.017453292519943295;
case 10:
if (this.radian) {
return Math.atan(parameter);
}return Math.atan(parameter) / 0.017453292519943295;
case 11:
return (Math.exp(parameter) - Math.exp(-parameter)) / 2;
case 12:
return (Math.exp(parameter) + Math.exp(-parameter)) / 2;
case 13:
var a=Math.exp(parameter);
var b=Math.exp(-parameter);
return (a - b) / (a + b);
case 14:
return Math.log(parameter + Math.sqrt(parameter * parameter + 1));
case 15:
return Math.log(parameter + Math.sqrt(parameter * parameter - 1));
case 16:
return Math.log((1 + parameter) / (1 - parameter)) / 2;
case 17:
return Math.ceil(parameter);
case 18:
return Math.floor(parameter);
case 19:
return Math.round(parameter);
case 20:
return Math.exp(parameter);
case 21:
return parameter * parameter;
case 22:
return Math.sqrt(parameter);
case 23:
if (parameter == 0.0 ) {
return 0;
} else if (parameter > 0.0 ) {
return 1;
} else {
return -1;
}case 24:
if (parameter < 0 ) {
return 0;
}return 1;
case 25:
return parameter * Math.random();
default:
this.error=8;
return NaN;
}
}, p$1);

Clazz.newMeth(C$, 'builtInExtFunction$I$D$D', function ($function, param1, param2) {
switch ($function) {
case 0:
return Math.min(param1, param2);
case 1:
return Math.max(param1, param2);
case 2:
return Math.IEEEremainder(param1, param2);
case 3:
return Math.atan2(param1, param2);
default:
this.error=8;
return NaN;
}
}, p$1);

Clazz.newMeth(C$, 'evaluateSubFunction', function () {
var stack_pointer=-1;
var code_pointer=0;
var destination;
var code;
var codeLength=this.postfix_code.length$();
while (true){
try {
if (code_pointer == codeLength) {
return this.stack[0];
}code=this.postfix_code.charAt$I(code_pointer++);
} catch (e) {
if (Clazz.exceptionOf(e,"StringIndexOutOfBoundsException")){
return this.stack[0];
} else {
throw e;
}
}
try {
switch (code.$c()) {
case 43:
this.stack[stack_pointer - 1] += this.stack[stack_pointer];
stack_pointer--;
break;
case 45:
this.stack[stack_pointer - 1] -= this.stack[stack_pointer];
stack_pointer--;
break;
case 42:
this.stack[stack_pointer - 1] *= this.stack[stack_pointer];
stack_pointer--;
break;
case 47:
if (this.stack[stack_pointer] != 0 ) {
this.stack[stack_pointer - 1] /= this.stack[stack_pointer];
} else {
this.stack[stack_pointer - 1] /= 1.0E-128;
}stack_pointer--;
break;
case 94:
this.stack[stack_pointer - 1]=Math.pow(this.stack[stack_pointer - 1], this.stack[stack_pointer]);
stack_pointer--;
break;
case 95:
this.stack[stack_pointer]=-this.stack[stack_pointer];
break;
case 1:
destination=code_pointer + (this.postfix_code.charCodeAt$I(code_pointer++));
while (code_pointer < destination){
if (this.postfix_code.charAt$I(code_pointer++) == "\u00ff") {
this.numberindex++;
}}
break;
case 2:
stack_pointer--;
this.stack[stack_pointer]=(this.stack[stack_pointer] < this.stack[stack_pointer + 1] ) ? 1.0 : 0.0;
break;
case 3:
stack_pointer--;
this.stack[stack_pointer]=(this.stack[stack_pointer] > this.stack[stack_pointer + 1] ) ? 1.0 : 0.0;
break;
case 4:
stack_pointer--;
this.stack[stack_pointer]=(this.stack[stack_pointer] <= this.stack[stack_pointer + 1] ) ? 1.0 : 0.0;
break;
case 5:
stack_pointer--;
this.stack[stack_pointer]=(this.stack[stack_pointer] >= this.stack[stack_pointer + 1] ) ? 1.0 : 0.0;
break;
case 7:
stack_pointer--;
this.stack[stack_pointer]=(this.stack[stack_pointer] == this.stack[stack_pointer + 1] ) ? 1.0 : 0.0;
break;
case 6:
stack_pointer--;
this.stack[stack_pointer]=(this.stack[stack_pointer] != this.stack[stack_pointer + 1] ) ? 1.0 : 0.0;
break;
case 8:
if (this.stack[stack_pointer--] == 0.0 ) {
destination=code_pointer + (this.postfix_code.charCodeAt$I(code_pointer++));
while (code_pointer < destination){
if (this.postfix_code.charAt$I(code_pointer++) == "\u00ff") {
this.numberindex++;
}}
} else {
code_pointer++;
}break;
case 9:
break;
case 10:
stack_pointer--;
if ((this.stack[stack_pointer] != 0.0 ) && (this.stack[stack_pointer + 1] != 0.0 ) ) {
this.stack[stack_pointer]=1.0;
} else {
this.stack[stack_pointer]=0.0;
}break;
case 11:
stack_pointer--;
if ((this.stack[stack_pointer] != 0.0 ) || (this.stack[stack_pointer + 1] != 0.0 ) ) {
this.stack[stack_pointer]=1.0;
} else {
this.stack[stack_pointer]=0.0;
}break;
case 12:
this.stack[stack_pointer]=(this.stack[stack_pointer] == 0.0 ) ? 1.0 : 0.0;
break;
case 255:
this.stack[++stack_pointer]=this.number[this.numberindex++];
break;
case 253:
this.stack[++stack_pointer]=3.141592653589793;
break;
case 254:
this.stack[++stack_pointer]=2.718281828459045;
break;
default:
if (code.$c() >= 3000 ) {
this.stack[++stack_pointer]=this.refvalue[code.$c() - 3000];
} else if (code.$c() >= 2000 ) {
this.stack[++stack_pointer]=this.var_value[code.$c() - 2000];
} else if (code.$c() >= 1026 ) {
this.stack[stack_pointer - 1]=p$1.builtInExtFunction$I$D$D.apply(this, [code.$c() - 1026, this.stack[stack_pointer - 1], this.stack[stack_pointer]]);
stack_pointer--;
} else if (code.$c() >= 1000 ) {
this.stack[stack_pointer]=p$1.builtInFunction$I$D.apply(this, [code.$c() - 1000, this.stack[stack_pointer]]);
} else {
this.error=8;
return NaN;
}}
} catch (e$$) {
if (Clazz.exceptionOf(e$$,"ArrayIndexOutOfBoundsException")){
var oe = e$$;
{
this.error=9;
return NaN;
}
} else if (Clazz.exceptionOf(e$$,"NullPointerException")){
var ne = e$$;
{
this.error=8;
return NaN;
}
} else {
throw e$$;
}
}
}
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.LOG10=Math.log(10);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 10:48:33 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
