(function(){var P$=Clazz.newPackage("org.opensourcephysics.numerics.specialfunctions"),I$=[[0,'org.opensourcephysics.js.JSUtil','org.opensourcephysics.numerics.specialfunctions.Messages']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Factorials");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['cof','double[]','fac','long[]']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'gammaln$D', function (x) {
var y=x;
var tmp=x + 5.5;
tmp -= (x + 0.5) * Math.log(tmp);
var sum=1.000000000190015;
for (var j=0; j <= 5; j++) {
sum += C$.cof[j] / ++y;
}
return -tmp + Math.log(2.5066282746310007 * sum / x);
}, 1);

Clazz.newMeth(C$, 'factorial$I', function (n) {
if (n < 0) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,[$I$(2).getString$S("Factorials.neg_val")]);
}if (n < C$.fac.length) {
return C$.fac[n];
}return Math.exp(C$.gammaln$D(n + 1.0));
}, 1);

Clazz.newMeth(C$, 'logFactorial$I', function (n) {
if (n < 0) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,[$I$(2).getString$S("Factorials.log_neg_val")]);
}return C$.gammaln$D(n + 1.0);
}, 1);

Clazz.newMeth(C$, 'poisson$D$I', function (nu, n) {
return Math.exp(n * Math.log(nu) - nu - C$.logFactorial$I(n));
}, 1);

Clazz.newMeth(C$, 'logChoose$I$I', function (n, k) {
return C$.logFactorial$I(n) - C$.logFactorial$I(k) - C$.logFactorial$I(n - k) ;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.cof=Clazz.array(Double.TYPE, -1, [76.18009172947146, -86.50532032941678, 24.01409824083091, -1.231739572450155, 0.001208650973866179, -5.395239384953E-6]);
{
var val=1;
var maxN=1;
if ($I$(1).isJS) {
maxN=13;
} else while (val * maxN >= val){
val=val * maxN;
maxN++;
}
C$.fac=Clazz.array(Long.TYPE, [maxN]);
C$.fac[0]=1;
for (var i=1; i < maxN; i++) {
C$.fac[i]=C$.fac[i - 1] * i;
}
};
};
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 10:48:33 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
