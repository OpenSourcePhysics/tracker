(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[[0,'org.opensourcephysics.media.core.VideoPanel',['java.awt.geom.Point2D','.Double'],'java.util.TreeMap','org.opensourcephysics.media.core.VideoPlayer','org.opensourcephysics.media.core.VidCartesianCoordinateStringBuilder','org.opensourcephysics.media.core.ImageCoordSystem','java.awt.Dimension','org.opensourcephysics.media.core.VideoClip','org.opensourcephysics.controls.XMLControlElement','org.opensourcephysics.controls.XML','org.opensourcephysics.controls.OSPLog','javax.swing.SwingUtilities','org.opensourcephysics.media.core.Trackable','org.opensourcephysics.media.core.Filter','java.awt.image.BufferedImage',['org.opensourcephysics.media.core.VideoPanel','.Loader']]],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VideoPanel", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.display.InteractivePanel', 'java.beans.PropertyChangeListener');
C$.$classes$=[['Loader',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.changed=false;
this.video=null;
this.playerVisible=true;
this.drawingInImageSpace=false;
this.pt=Clazz.new_($I$(2,1));
this.filterClasses=Clazz.new_($I$(3,1));
},1);

C$.$fields$=[['Z',['changed','playerVisible','drawingInImageSpace'],'D',['imageWidth','imageHeight','xOffset','yOffset','imageBorder'],'S',['defaultFileName'],'O',['player','org.opensourcephysics.media.core.VideoPlayer','mousePanel','org.opensourcephysics.display.TextPanel','+messagePanel','video','org.opensourcephysics.media.core.Video','coords','org.opensourcephysics.media.core.ImageCoordSystem','pt','java.awt.geom.Point2D','dataFile','java.io.File','filterClasses','java.util.Map']]
,['I',['defaultWidth','defaultHeight']]]

Clazz.newMeth(C$, 'c$', function () {
C$.c$$org_opensourcephysics_media_core_Video.apply(this, [null]);
}, 1);

Clazz.newMeth(C$, 'c$$org_opensourcephysics_media_core_Video', function (video) {
Clazz.super_(C$, this);
this.setSquareAspect$Z(true);
this.player=Clazz.new_($I$(4,1).c$$org_opensourcephysics_media_core_VideoPanel,[this]);
this.player.addPropertyChangeListener$S$java_beans_PropertyChangeListener("videoclip", this);
this.player.addPropertyChangeListener$S$java_beans_PropertyChangeListener("stepnumber", this);
this.player.addPropertyChangeListener$S$java_beans_PropertyChangeListener("frameduration", this);
this.add$java_awt_Component$O(this.player, "South");
var clip=this.player.getVideoClip$();
clip.addPropertyChangeListener$S$java_beans_PropertyChangeListener("startframe", this);
clip.addPropertyChangeListener$S$java_beans_PropertyChangeListener("stepsize", this);
clip.addPropertyChangeListener$S$java_beans_PropertyChangeListener("stepcount", this);
clip.addPropertyChangeListener$S$java_beans_PropertyChangeListener("framecount", this);
clip.addPropertyChangeListener$S$java_beans_PropertyChangeListener("starttime", this);
clip.addPropertyChangeListener$S$java_beans_PropertyChangeListener("adjusting", this);
this.mousePanel=this.blMessageBox;
this.messagePanel=this.brMessageBox;
this.setCoordinateStringBuilder$org_opensourcephysics_display_axes_CoordinateStringBuilder(Clazz.new_($I$(5,1)));
this.coords=Clazz.new_($I$(6,1));
this.setVideo$org_opensourcephysics_media_core_Video(video);
if ((video != null ) && (video.getImage$().getWidth$() > 0) ) {
this.setImageWidth$D(video.getImage$().getWidth$());
this.setImageHeight$D(video.getImage$().getHeight$());
} else {
this.setImageWidth$D(C$.defaultWidth);
this.setImageHeight$D(C$.defaultHeight);
}var w=(this.getImageWidth$()|0);
var h=(this.getImageHeight$()|0);
this.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(7,1).c$$I$I,[w, h + this.player.$height]));
this.coords.setAllOriginsXY$D$D(this.imageWidth / 2, this.imageHeight / 2);
}, 1);

Clazz.newMeth(C$, 'setVideo$org_opensourcephysics_media_core_Video$Z', function (newVideo, playAllSteps) {
if (newVideo === this.video ) {
return;
}var prev=this.video;
var prevClip=this.getPlayer$().getVideoClip$();
var newClip=Clazz.new_($I$(8,1).c$$org_opensourcephysics_media_core_Video,[newVideo]);
if (newVideo == null  && prevClip != null  ) {
var control=Clazz.new_($I$(9,1).c$$O,[prevClip]);
control.setValue$S$O("video", null);
control.loadObject$O(newClip);
}newClip.setPlayAllSteps$Z(playAllSteps);
this.getPlayer$().setVideoClip$org_opensourcephysics_media_core_VideoClip(newClip);
if (prev != null ) {
prev.dispose$();
}});

Clazz.newMeth(C$, 'setVideo$org_opensourcephysics_media_core_Video', function (newVideo) {
this.setVideo$org_opensourcephysics_media_core_Video$Z(newVideo, false);
});

Clazz.newMeth(C$, 'getVideo$', function () {
return this.video;
});

Clazz.newMeth(C$, 'getImageWidth$', function () {
return this.imageWidth;
});

Clazz.newMeth(C$, 'setImageWidth$D', function (w) {
if (this.video != null ) {
var vidImage=this.video.getImage$();
if (vidImage != null ) {
w=Math.max(w, vidImage.getWidth$());
}}this.imageWidth=w;
});

Clazz.newMeth(C$, 'getImageHeight$', function () {
return this.imageHeight;
});

Clazz.newMeth(C$, 'setImageHeight$D', function (h) {
if (this.video != null ) {
var vidImage=this.video.getImage$();
if (vidImage != null ) {
h=Math.max(h, vidImage.getHeight$());
}}this.imageHeight=h;
});

Clazz.newMeth(C$, 'getImageBorder$', function () {
return this.imageBorder;
});

Clazz.newMeth(C$, 'setImageBorder$D', function (borderFraction) {
this.imageBorder=borderFraction;
});

Clazz.newMeth(C$, 'setCoords$org_opensourcephysics_media_core_ImageCoordSystem', function (newCoords) {
if (this.video != null ) {
this.video.setCoords$org_opensourcephysics_media_core_ImageCoordSystem(newCoords);
} else {
this.coords=newCoords;
}});

Clazz.newMeth(C$, 'getCoords$', function () {
return this.coords;
});

Clazz.newMeth(C$, 'setDataFile$java_io_File', function (file) {
var prev=this.dataFile;
this.dataFile=file;
if (file != null ) {
this.defaultFileName=$I$(10,"forwardSlash$S",[file.getName$()]);
}this.firePropertyChange$S$O$O("datafile", prev, this.dataFile);
$I$(11).fine$S("Data file: " + file);
});

Clazz.newMeth(C$, 'getDataFile$', function () {
return this.dataFile;
});

Clazz.newMeth(C$, 'getFilePath$', function () {
return this.defaultFileName;
});

Clazz.newMeth(C$, 'setDrawingInImageSpace$Z', function (imagespace) {
this.drawingInImageSpace=imagespace;
if (imagespace) {
this.setAutoscaleX$Z(false);
this.setAutoscaleY$Z(false);
} else {
this.setAutoscaleX$Z(true);
this.setAutoscaleY$Z(true);
}this.firePropertyChange$S$O$O("imagespace", null,  Boolean.from(imagespace));
this.repaint$();
});

Clazz.newMeth(C$, 'isDrawingInImageSpace$', function () {
return this.drawingInImageSpace;
});

Clazz.newMeth(C$, 'getPlayer$', function () {
return this.player;
});

Clazz.newMeth(C$, 'setPlayerVisible$Z', function (visible) {
if (visible == this.playerVisible ) {
return;
}var setPlayerVis=((P$.VideoPanel$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPanel$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
this.b$['org.opensourcephysics.media.core.VideoPanel'].playerVisible=this.$finals$.visible;
if (this.b$['org.opensourcephysics.media.core.VideoPanel'].playerVisible) {
this.b$['java.awt.Container'].add$java_awt_Component$O.apply(this.b$['java.awt.Container'], [this.b$['org.opensourcephysics.media.core.VideoPanel'].player, "South"]);
} else {
this.b$['java.awt.Container'].remove$java_awt_Component.apply(this.b$['java.awt.Container'], [this.b$['org.opensourcephysics.media.core.VideoPanel'].player]);
}this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
});
})()
), Clazz.new_(P$.VideoPanel$1.$init$,[this, {visible:visible}]));
$I$(12).invokeLater$Runnable(setPlayerVis);
});

Clazz.newMeth(C$, 'isPlayerVisible$', function () {
return this.playerVisible;
});

Clazz.newMeth(C$, 'getStepNumber$', function () {
return this.getPlayer$().getStepNumber$();
});

Clazz.newMeth(C$, 'getFrameNumber$', function () {
return this.getPlayer$().getFrameNumber$();
});

Clazz.newMeth(C$, 'getDrawables$', function () {
var list=C$.superclazz.prototype.getDrawables$.apply(this, []);
if (this.isDrawingInImageSpace$()) {
for (var d, $d = list.iterator$(); $d.hasNext$()&&((d=($d.next$())),1);) {
if (!Clazz.getClass($I$(13),[]).isInstance$O(d)) {
list.remove$O(d);
}}
}return list;
});

Clazz.newMeth(C$, 'addDrawable$org_opensourcephysics_display_Drawable', function (drawable) {
if (drawable == null ) {
return;
}if (Clazz.instanceOf(drawable, "org.opensourcephysics.media.core.Video")) {
this.setVideo$org_opensourcephysics_media_core_Video(drawable);
} else {
C$.superclazz.prototype.addDrawable$org_opensourcephysics_display_Drawable.apply(this, [drawable]);
}this.repaint$();
});

Clazz.newMeth(C$, 'removeDrawable$org_opensourcephysics_display_Drawable', function (drawable) {
if (drawable === this.video ) {
this.setVideo$org_opensourcephysics_media_core_Video(null);
} else {
C$.superclazz.prototype.removeDrawable$org_opensourcephysics_display_Drawable.apply(this, [drawable]);
}});

Clazz.newMeth(C$, 'removeObjectsOfClass$Class', function (c) {
if (this.video.getClass$() === c ) {
this.setVideo$org_opensourcephysics_media_core_Video(null);
} else {
C$.superclazz.prototype.removeObjectsOfClass$Class.apply(this, [c]);
}});

Clazz.newMeth(C$, 'clear$', function () {
C$.superclazz.prototype.clear$.apply(this, []);
if (this.video != null ) {
C$.superclazz.prototype.addDrawable$org_opensourcephysics_display_Drawable.apply(this, [this.video]);
}});

Clazz.newMeth(C$, 'addFilter$Class', function (filterClass) {
if (Clazz.getClass($I$(14)).isAssignableFrom$Class(filterClass)) {
var name=filterClass.getName$();
this.filterClasses.put$O$O(name, filterClass);
}});

Clazz.newMeth(C$, 'removeFilter$Class', function (filterClass) {
if (Clazz.getClass($I$(14)).isAssignableFrom$Class(filterClass)) {
var name=filterClass.getName$();
this.filterClasses.remove$O(name);
}});

Clazz.newMeth(C$, 'clearFilters$', function () {
this.filterClasses.clear$();
});

Clazz.newMeth(C$, 'getFilters$', function () {
return this.filterClasses;
});

Clazz.newMeth(C$, 'isShowCoordinates$', function () {
return this.showCoordinates;
});

Clazz.newMeth(C$, 'hideMouseBox$', function () {
if (this.mousePanel.isVisible$()) {
this.mousePanel.setText$S(null);
}});

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (e) {
var name=e.getPropertyName$();
if (name.equals$O("size")) {
var dim=e.getNewValue$();
this.setImageWidth$D(dim.width);
this.setImageHeight$D(dim.height);
} else if (name.equals$O("coords")) {
this.coords=this.video.getCoords$();
} else if (name.equals$O("image") || name.equals$O("videoVisible") ) {
this.repaint$();
} else if (name.equals$O("stepnumber")) {
this.repaint$();
} else if (name.equals$O("videoclip")) {
var oldClip=e.getOldValue$();
oldClip.removePropertyChangeListener$S$java_beans_PropertyChangeListener("startframe", this);
oldClip.removePropertyChangeListener$S$java_beans_PropertyChangeListener("stepsize", this);
oldClip.removePropertyChangeListener$S$java_beans_PropertyChangeListener("stepcount", this);
oldClip.removePropertyChangeListener$S$java_beans_PropertyChangeListener("framecount", this);
oldClip.removePropertyChangeListener$S$java_beans_PropertyChangeListener("starttime", this);
oldClip.removePropertyChangeListener$S$java_beans_PropertyChangeListener("adjusting", this);
var clip=e.getNewValue$();
clip.addPropertyChangeListener$S$java_beans_PropertyChangeListener("startframe", this);
clip.addPropertyChangeListener$S$java_beans_PropertyChangeListener("stepsize", this);
clip.addPropertyChangeListener$S$java_beans_PropertyChangeListener("stepcount", this);
clip.addPropertyChangeListener$S$java_beans_PropertyChangeListener("framecount", this);
clip.addPropertyChangeListener$S$java_beans_PropertyChangeListener("starttime", this);
clip.addPropertyChangeListener$S$java_beans_PropertyChangeListener("adjusting", this);
if (this.video != null ) {
this.video.removePropertyChangeListener$S$java_beans_PropertyChangeListener("coords", this);
this.video.removePropertyChangeListener$S$java_beans_PropertyChangeListener("image", this);
this.video.removePropertyChangeListener$S$java_beans_PropertyChangeListener("filterChanged", this);
this.video.removePropertyChangeListener$S$java_beans_PropertyChangeListener("videoVisible", this);
this.video.removePropertyChangeListener$S$java_beans_PropertyChangeListener("size", this);
C$.superclazz.prototype.removeDrawable$org_opensourcephysics_display_Drawable.apply(this, [this.video]);
}this.video=clip.getVideo$();
if (this.video != null ) {
this.video.addPropertyChangeListener$S$java_beans_PropertyChangeListener("coords", this);
this.video.addPropertyChangeListener$S$java_beans_PropertyChangeListener("image", this);
this.video.addPropertyChangeListener$S$java_beans_PropertyChangeListener("filterChanged", this);
this.video.addPropertyChangeListener$S$java_beans_PropertyChangeListener("videoVisible", this);
this.video.addPropertyChangeListener$S$java_beans_PropertyChangeListener("size", this);
if (this.video.isMeasured$()) {
this.coords=this.video.getCoords$();
} else {
this.video.setCoords$org_opensourcephysics_media_core_ImageCoordSystem(this.coords);
}{
this.drawableList.add$I$O(0, this.video);
}var vidImage=this.video.getImage$();
if (vidImage != null ) {
this.setImageWidth$D(vidImage.getWidth$());
this.setImageHeight$D(vidImage.getHeight$());
}}this.repaint$();
}});

Clazz.newMeth(C$, 'importData$org_opensourcephysics_display_Data$O', function (data, source) {
return null;
});

Clazz.newMeth(C$, 'paintEverything$java_awt_Graphics', function (g) {
if (this.playerVisible) {
this.bottomGutter+=this.player.$height;
}C$.superclazz.prototype.paintEverything$java_awt_Graphics.apply(this, [g]);
if (this.playerVisible) {
this.bottomGutter-=this.player.$height;
}});

Clazz.newMeth(C$, 'scale$java_util_ArrayList', function (drawables) {
if (this.drawingInImageSpace) {
this.xminPreferred=-this.imageBorder * this.imageWidth + this.xOffset;
this.xmaxPreferred=this.imageWidth + this.imageBorder * this.imageWidth + this.xOffset;
this.yminPreferred=this.imageHeight + this.imageBorder * this.imageHeight + this.yOffset;
this.ymaxPreferred=-this.imageBorder * this.imageHeight + this.yOffset;
}C$.superclazz.prototype.scale$java_util_ArrayList.apply(this, [drawables]);
});

Clazz.newMeth(C$, 'checkImage$', function () {
var d=this.getSize$();
if (this.playerVisible) {
d.height-=this.player.$height;
}if ((d.width <= 2) || (d.height <= 2) ) {
return false;
}if ((this.offscreenImage == null ) || (d.width != this.offscreenImage.getWidth$()) || (d.height != this.offscreenImage.getHeight$())  ) {
this.offscreenImage=Clazz.new_($I$(15,1).c$$I$I$I,[d.width, d.height, 1]);
}if (this.offscreenImage == null ) {
return false;
}return true;
});

Clazz.newMeth(C$, 'getWorldMousePoint$', function () {
this.pt.setLocation$D$D(this.getMouseX$(), this.getMouseY$());
if (this.isDrawingInImageSpace$()) {
var n=this.getFrameNumber$();
var toWorld=this.getCoords$().getToWorldTransform$I(n);
toWorld.transform$java_awt_geom_Point2D$java_awt_geom_Point2D(this.pt, this.pt);
}return this.pt;
});

Clazz.newMeth(C$, 'getXYCoordinateStringBuilder$org_opensourcephysics_media_core_TPoint', function (point) {
return ;
});

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(16,1));
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.defaultWidth=640;
C$.defaultHeight=480;
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.VideoPanel, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XML.ObjectLoader']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var vidPanel=obj;
control.setValue$S$O("videoclip", vidPanel.getPlayer$().getVideoClip$());
control.setValue$S$O("coords", vidPanel.getCoords$());
var list=vidPanel.getDrawables$();
list.remove$O(vidPanel.getVideo$());
if (!list.isEmpty$()) {
control.setValue$S$O("drawables", list);
}});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
return Clazz.new_($I$(1,1));
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var vidPanel=obj;
var clip=control.getObject$S("videoclip");
if (clip != null ) {
vidPanel.getPlayer$().setVideoClip$org_opensourcephysics_media_core_VideoClip(clip);
}vidPanel.setCoords$org_opensourcephysics_media_core_ImageCoordSystem(control.getObject$S("coords"));
var drawables=control.getObject$S("drawables");
if (drawables != null ) {
var it=drawables.iterator$();
while (it.hasNext$()){
vidPanel.addDrawable$org_opensourcephysics_display_Drawable(it.next$());
}
}return obj;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 10:48:33 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
