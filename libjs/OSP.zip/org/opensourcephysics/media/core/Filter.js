(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[[0,'javax.swing.event.SwingPropertyChangeSupport','javax.swing.AbstractAction','org.opensourcephysics.media.core.MediaRes','javax.swing.JCheckBoxMenuItem','javax.swing.JMenuItem','javax.swing.JButton','javax.swing.JOptionPane','org.opensourcephysics.controls.OSPLog','org.opensourcephysics.controls.XMLControlElement','org.opensourcephysics.tools.DataTool','javax.swing.JMenu']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Filter");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.inspectorX=-2147483648;
this.enabled=true;
this.changed=false;
},1);

C$.$fields$=[['Z',['inspectorVisible','enabled','changed','hasInspector'],'I',['inspectorX','inspectorY','w','h'],'S',['name','previousState'],'O',['source','java.awt.image.BufferedImage','+input','+output','gIn','java.awt.Graphics2D','vidPanel','org.opensourcephysics.media.core.VideoPanel','support','java.beans.PropertyChangeSupport','enabledAction','javax.swing.Action','enabledItem','javax.swing.JCheckBoxMenuItem','deleteItem','javax.swing.JMenuItem','+propertiesItem','+copyItem','frame','java.awt.Frame','closeButton','javax.swing.JButton','+ableButton','+clearButton','stack','org.opensourcephysics.media.core.FilterStack']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
this.support=Clazz.new_($I$(1,1).c$$O,[this]);
this.name=this.getClass$().getSimpleName$();
var i=this.name.indexOf$S("Filter");
if ((i > 0) && (i < this.name.length$() - 1) ) {
this.name=this.name.substring$I$I(0, i);
}this.enabledAction=((P$.Filter$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "Filter$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.Filter'].setEnabled$Z.apply(this.b$['org.opensourcephysics.media.core.Filter'], [this.b$['org.opensourcephysics.media.core.Filter'].enabledItem.isSelected$()]);
this.b$['org.opensourcephysics.media.core.Filter'].refresh$.apply(this.b$['org.opensourcephysics.media.core.Filter'], []);
});
})()
), Clazz.new_([this, null, $I$(3).getString$S("Filter.MenuItem.Enabled")],$I$(2,1).c$$S,P$.Filter$1));
this.enabledItem=Clazz.new_($I$(4,1).c$$javax_swing_Action,[this.enabledAction]);
this.enabledItem.setSelected$Z(this.isEnabled$());
this.propertiesItem=Clazz.new_([$I$(3).getString$S("Filter.MenuItem.Properties")],$I$(5,1).c$$S);
this.propertiesItem.addActionListener$java_awt_event_ActionListener(((P$.Filter$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "Filter$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var inspector=this.b$['org.opensourcephysics.media.core.Filter'].getInspector$.apply(this.b$['org.opensourcephysics.media.core.Filter'], []);
if (inspector != null ) {
inspector.setVisible$Z(true);
}});
})()
), Clazz.new_(P$.Filter$2.$init$,[this, null])));
this.copyItem=Clazz.new_([$I$(3).getString$S("Filter.MenuItem.Copy")],$I$(5,1).c$$S);
this.copyItem.addActionListener$java_awt_event_ActionListener(((P$.Filter$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "Filter$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.Filter'].copy$.apply(this.b$['org.opensourcephysics.media.core.Filter'], []);
});
})()
), Clazz.new_(P$.Filter$3.$init$,[this, null])));
this.closeButton=Clazz.new_($I$(6,1));
this.closeButton.addActionListener$java_awt_event_ActionListener(((P$.Filter$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "Filter$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var inspector=this.b$['org.opensourcephysics.media.core.Filter'].getInspector$.apply(this.b$['org.opensourcephysics.media.core.Filter'], []);
if (inspector != null ) {
if (this.b$['org.opensourcephysics.media.core.Filter'].isChanged$.apply(this.b$['org.opensourcephysics.media.core.Filter'], []) && this.b$['org.opensourcephysics.media.core.Filter'].previousState != null  ) {
this.b$['org.opensourcephysics.media.core.Filter'].changed=false;
this.b$['org.opensourcephysics.media.core.Filter'].support.firePropertyChange$S$O$O("filterChanged", this.b$['org.opensourcephysics.media.core.Filter'].previousState, this.b$['org.opensourcephysics.media.core.Filter']);
this.b$['org.opensourcephysics.media.core.Filter'].previousState=null;
}inspector.setVisible$Z(false);
}});
})()
), Clazz.new_(P$.Filter$4.$init$,[this, null])));
this.ableButton=Clazz.new_($I$(6,1));
this.ableButton.addActionListener$java_awt_event_ActionListener(((P$.Filter$5||
(function(){/*a*/var C$=Clazz.newClass(P$, "Filter$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.Filter'].enabledItem.setSelected$Z(!this.b$['org.opensourcephysics.media.core.Filter'].enabledItem.isSelected$());
this.b$['org.opensourcephysics.media.core.Filter'].enabledAction.actionPerformed$java_awt_event_ActionEvent(null);
});
})()
), Clazz.new_(P$.Filter$5.$init$,[this, null])));
this.clearButton=Clazz.new_($I$(6,1));
this.clearButton.addActionListener$java_awt_event_ActionListener(((P$.Filter$6||
(function(){/*a*/var C$=Clazz.newClass(P$, "Filter$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.Filter'].clear$.apply(this.b$['org.opensourcephysics.media.core.Filter'], []);
});
})()
), Clazz.new_(P$.Filter$6.$init$,[this, null])));
}, 1);

Clazz.newMeth(C$, 'clear$', function () {
});

Clazz.newMeth(C$, 'isChanged$', function () {
return this.changed;
});

Clazz.newMeth(C$, 'setVideoPanel$org_opensourcephysics_media_core_VideoPanel', function (panel) {
this.vidPanel=panel;
this.frame=this.vidPanel == null  ? null : $I$(7).getFrameForComponent$java_awt_Component(this.vidPanel);
});

Clazz.newMeth(C$, 'refresh$', function () {
this.enabledItem.setText$S($I$(3).getString$S("Filter.MenuItem.Enabled"));
this.propertiesItem.setText$S($I$(3).getString$S("Filter.MenuItem.Properties"));
this.closeButton.setText$S($I$(3).getString$S("Filter.Button.Close"));
this.ableButton.setText$S(this.isEnabled$() ? $I$(3).getString$S("Filter.Button.Disable") : $I$(3).getString$S("Filter.Button.Enable"));
this.clearButton.setText$S($I$(3).getString$S("Filter.Button.Clear"));
this.clearButton.setEnabled$Z((this.isEnabled$()));
});

Clazz.newMeth(C$, 'finalize$', function () {
$I$(8,"finer$S",[this.getClass$().getSimpleName$() + " resources released by garbage collector"]);
});

Clazz.newMeth(C$, 'setEnabled$Z', function (enabled) {
if (this.enabled == enabled ) {
return;
}this.enabled=enabled;
this.support.firePropertyChange$S$O$O("enabled", null,  Boolean.from(enabled));
});

Clazz.newMeth(C$, 'isEnabled$', function () {
return this.enabled;
});

Clazz.newMeth(C$, 'copy$', function () {
var control=Clazz.new_($I$(9,1).c$$O,[this]);
$I$(10,"copy$S",[control.toXML$()]);
});

Clazz.newMeth(C$, 'dispose$', function () {
this.removePropertyChangeListener$java_beans_PropertyChangeListener(this.stack);
this.stack=null;
var inspector=this.getInspector$();
if (inspector != null ) {
inspector.setVisible$Z(false);
inspector.dispose$();
}this.setVideoPanel$org_opensourcephysics_media_core_VideoPanel(null);
if (this.gIn != null ) this.gIn.dispose$();
if (this.source != null ) this.source.flush$();
if (this.input != null ) this.input.flush$();
if (this.output != null ) this.output.flush$();
});

Clazz.newMeth(C$, 'addPropertyChangeListener$java_beans_PropertyChangeListener', function (listener) {
this.support.addPropertyChangeListener$java_beans_PropertyChangeListener(listener);
});

Clazz.newMeth(C$, 'addPropertyChangeListener$S$java_beans_PropertyChangeListener', function (property, listener) {
this.support.addPropertyChangeListener$S$java_beans_PropertyChangeListener(property, listener);
});

Clazz.newMeth(C$, 'removePropertyChangeListener$java_beans_PropertyChangeListener', function (listener) {
this.support.removePropertyChangeListener$java_beans_PropertyChangeListener(listener);
});

Clazz.newMeth(C$, 'removePropertyChangeListener$S$java_beans_PropertyChangeListener', function (property, listener) {
this.support.removePropertyChangeListener$S$java_beans_PropertyChangeListener(property, listener);
});

Clazz.newMeth(C$, 'getMenu$org_opensourcephysics_media_core_Video', function (video) {
var menu=Clazz.new_([$I$(3).getString$S("VideoFilter." + this.name)],$I$(11,1).c$$S);
if (this.hasInspector) {
menu.add$javax_swing_JMenuItem(this.propertiesItem);
menu.addSeparator$();
}menu.add$javax_swing_JMenuItem(this.enabledItem);
menu.addSeparator$();
menu.add$javax_swing_JMenuItem(this.copyItem);
if (video != null ) {
menu.addSeparator$();
this.deleteItem=Clazz.new_([$I$(3).getString$S("Filter.MenuItem.Delete")],$I$(5,1).c$$S);
var filterStack=video.getFilterStack$();
this.deleteItem.addActionListener$java_awt_event_ActionListener(((P$.Filter$7||
(function(){/*a*/var C$=Clazz.newClass(P$, "Filter$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.$finals$.filterStack.removeFilter$org_opensourcephysics_media_core_Filter(this.b$['org.opensourcephysics.media.core.Filter']);
});
})()
), Clazz.new_(P$.Filter$7.$init$,[this, {filterStack:filterStack}])));
menu.add$javax_swing_JMenuItem(this.deleteItem);
}return menu;
});
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 10:48:32 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
