(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),I$=[[0,'java.awt.Color',['java.awt.geom.Line2D','.Double'],['java.awt.geom.Point2D','.Double'],'java.awt.geom.AffineTransform','java.awt.geom.GeneralPath','org.opensourcephysics.display.ArrowLoader']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Arrow", null, null, 'org.opensourcephysics.display.Drawable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.headSize=8;
this.color=$I$(1).black;
this.x=0;
this.y=0;
this.a=0;
this.b=0;
},1);

C$.$fields$=[['D',['x','y','a','b'],'F',['headSize'],'O',['color','java.awt.Color']]]

Clazz.newMeth(C$, 'c$$D$D$D$D', function (_x, _y, _a, _b) {
;C$.$init$.apply(this);
this.x=_x;
this.y=_y;
this.a=_a;
this.b=_b;
}, 1);

Clazz.newMeth(C$, 'getX$', function () {
return this.x;
});

Clazz.newMeth(C$, 'setX$D', function (x) {
this.setXY$D$D(x, this.y);
});

Clazz.newMeth(C$, 'getY$', function () {
return this.y;
});

Clazz.newMeth(C$, 'setY$D', function (y) {
this.setXY$D$D(this.x, y);
});

Clazz.newMeth(C$, 'setXY$D$D', function (x, y) {
this.x=x;
this.y=y;
});

Clazz.newMeth(C$, 'setColor$java_awt_Color', function (c) {
this.color=c;
});

Clazz.newMeth(C$, 'setXlength$D', function (dx) {
this.a=dx;
});

Clazz.newMeth(C$, 'setYlength$D', function (dy) {
this.b=dy;
});

Clazz.newMeth(C$, 'getXlength$', function () {
return this.a;
});

Clazz.newMeth(C$, 'getYlength$', function () {
return this.b;
});

Clazz.newMeth(C$, 'getHeadSize$', function () {
return this.headSize;
});

Clazz.newMeth(C$, 'setHeadSize$F', function (size) {
this.headSize=size;
});

Clazz.newMeth(C$, 'draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (panel, g) {
var g2=g;
var toPixels=panel.getPixelTransform$();
g2.setPaint$java_awt_Paint(this.color);
g2.draw$java_awt_Shape(toPixels.createTransformedShape$java_awt_Shape(Clazz.new_($I$(2,1).c$$D$D$D$D,[this.x, this.y, this.x + this.a, this.y + this.b])));
var pt=Clazz.new_($I$(3,1).c$$D$D,[this.x + this.a, this.y + this.b]);
pt=toPixels.transform$java_awt_geom_Point2D$java_awt_geom_Point2D(pt, pt);
var aspect=panel.isSquareAspect$() ? 1 : -toPixels.getScaleX$() / toPixels.getScaleY$();
var head=this.getHead$D(Math.atan2(this.b, aspect * this.a));
var temp=$I$(4,"getTranslateInstance$D$D",[pt.getX$(), pt.getY$()]).createTransformedShape$java_awt_Shape(head);
g2.fill$java_awt_Shape(temp);
g2.setPaint$java_awt_Paint($I$(1).BLACK);
});

Clazz.newMeth(C$, 'getHead$D', function (theta) {
var path=Clazz.new_($I$(5,1));
path.moveTo$F$F(1, 0);
path.lineTo$F$F(-this.headSize, -this.headSize / 2);
path.lineTo$F$F(-this.headSize, +this.headSize / 2);
path.closePath$();
var rot=$I$(4).getRotateInstance$D(-theta);
var head=rot.createTransformedShape$java_awt_Shape(path);
return head;
});

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(6,1));
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 10:48:28 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
