(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),I$=[[0,'java.util.ArrayList','java.awt.Rectangle','java.awt.Component']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "OSPLayout", null, 'java.awt.BorderLayout');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.list=Clazz.new_($I$(1,1));
this.layoutRect=Clazz.new_($I$(2,1).c$$I$I$I$I,[0, 0, 0, 0]);
this.components=Clazz.array($I$(3), [0]);
},1);

C$.$fields$=[['O',['list','java.util.ArrayList','topLeftCorner','java.awt.Component','+topRightCorner','+bottomLeftCorner','+bottomRightCorner','+centeredComp','layoutRect','java.awt.Rectangle','components','java.awt.Component[]']]
,['I',['macOffset']]]

Clazz.newMeth(C$, 'c$', function () {
C$.c$$I$I.apply(this, [0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (hgap, vgap) {
;C$.superclazz.c$$I$I.apply(this,[hgap, vgap]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addLayoutComponent$java_awt_Component$O', function (comp, constraints) {
if (!this.list.contains$O(comp)) {
this.list.add$O(comp);
this.components=this.list.toArray$OA(Clazz.array($I$(3), [0]));
}/*sync org.eclipse.jdt.core.dom.MethodInvocation*/(comp.getTreeLock$());
{
if ((Clazz.instanceOf(constraints, "java.lang.String")) && "TopLeftCorner".equals$O(constraints) ) {
this.list.remove$O(this.topLeftCorner);
this.topLeftCorner=comp;
} else if ((Clazz.instanceOf(constraints, "java.lang.String")) && "TopRightCorner".equals$O(constraints) ) {
this.list.remove$O(this.topRightCorner);
this.topRightCorner=comp;
} else if ((Clazz.instanceOf(constraints, "java.lang.String")) && "BottomLeftCorner".equals$O(constraints) ) {
this.list.remove$O(this.bottomLeftCorner);
this.bottomLeftCorner=comp;
} else if ((Clazz.instanceOf(constraints, "java.lang.String")) && "BottomRightCorner".equals$O(constraints) ) {
this.list.remove$O(this.bottomRightCorner);
this.bottomRightCorner=comp;
} else if ((Clazz.instanceOf(constraints, "java.lang.String")) && "Centered".equals$O(constraints) ) {
this.list.remove$O(this.centeredComp);
this.centeredComp=comp;
} else {
C$.superclazz.prototype.addLayoutComponent$java_awt_Component$O.apply(this, [comp, constraints]);
}}});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (comp) {
if (this.list.contains$O(comp)) {
this.list.remove$O(comp);
this.components=this.list.toArray$OA(Clazz.array($I$(3), [0]));
}/*sync org.eclipse.jdt.core.dom.MethodInvocation*/(comp.getTreeLock$());
{
if (comp === this.topLeftCorner ) {
this.topLeftCorner=null;
} else if (comp === this.topRightCorner ) {
this.topRightCorner=null;
} else if (comp === this.bottomLeftCorner ) {
this.bottomLeftCorner=null;
} else if (comp === this.bottomRightCorner ) {
this.bottomRightCorner=null;
} else if (comp === this.centeredComp ) {
this.centeredComp=null;
} else {
C$.superclazz.prototype.removeLayoutComponent$java_awt_Component.apply(this, [comp]);
}}});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
C$.superclazz.prototype.layoutContainer$java_awt_Container.apply(this, [target]);
this.doMyLayout$java_awt_Container(target);
});

Clazz.newMeth(C$, 'quickLayout$java_awt_Container$java_awt_Component', function (target, c) {
if ((target == null ) || (c == null ) ) {
return false;
}var insets=target.getInsets$();
var top=insets.top;
var bottom=target.getHeight$() - insets.bottom;
var left=insets.left;
var right=target.getWidth$() - insets.right;
if (this.topLeftCorner === c ) {
var d=c.getPreferredSize$();
c.setSize$I$I(d.width, d.height);
c.setBounds$I$I$I$I(left, top, d.width, d.height);
} else if (this.topRightCorner === c ) {
var d=c.getPreferredSize$();
c.setSize$I$I(d.width, d.height);
c.setBounds$I$I$I$I(right - d.width, top, d.width, d.height);
} else if (this.bottomLeftCorner === c ) {
var d=c.getPreferredSize$();
c.setSize$I$I(d.width, d.height);
c.setBounds$I$I$I$I(left, bottom - d.height, d.width, d.height);
} else if (this.bottomRightCorner === c ) {
var d=c.getPreferredSize$();
c.setSize$I$I(d.width, d.height);
c.setBounds$I$I$I$I(right - d.width - C$.macOffset , bottom - d.height, d.width, d.height);
} else if (this.centeredComp === c ) {
var d=c.getPreferredSize$();
c.setSize$I$I(d.width, d.height);
c.setBounds$I$I$I$I(((right - left - d.width )/2|0), ((bottom - top - d.height )/2|0), d.width, d.height);
} else {
return false;
}return true;
});

Clazz.newMeth(C$, 'checkLayoutRect$java_awt_Container$java_awt_Rectangle', function (c, viewRect) {
if (this.layoutRect.equals$O(viewRect)) {
return;
}this.layoutContainer$java_awt_Container(c);
});

Clazz.newMeth(C$, 'getComponents$', function () {
return this.components;
});

Clazz.newMeth(C$, 'doMyLayout$java_awt_Container', function (target) {
var insets=target.getInsets$();
var top=insets.top;
var bottom=target.getHeight$() - insets.bottom;
var left=insets.left;
var right=target.getWidth$() - insets.right;
var c=null;
if (this.topLeftCorner != null ) {
c=this.topLeftCorner;
var d=c.getPreferredSize$();
c.setSize$I$I(d.width, d.height);
c.setBounds$I$I$I$I(left, top, d.width, d.height);
}if (this.topRightCorner != null ) {
c=this.topRightCorner;
var d=c.getPreferredSize$();
c.setSize$I$I(d.width, d.height);
c.setBounds$I$I$I$I(right - d.width, top, d.width, d.height);
}if (this.bottomLeftCorner != null ) {
c=this.bottomLeftCorner;
var d=c.getPreferredSize$();
c.setSize$I$I(d.width, d.height);
c.setBounds$I$I$I$I(left, bottom - d.height, d.width, d.height);
}if (this.bottomRightCorner != null ) {
c=this.bottomRightCorner;
var d=c.getPreferredSize$();
c.setSize$I$I(d.width + C$.macOffset, d.height);
c.setBounds$I$I$I$I(right - d.width - C$.macOffset , bottom - d.height, d.width, d.height);
}if (this.centeredComp != null ) {
c=this.centeredComp;
var d=c.getPreferredSize$();
c.setSize$I$I(d.width, d.height);
c.setBounds$I$I$I$I(((right - left - d.width )/2|0), ((bottom - top - d.height )/2|0), d.width, d.height);
}});

C$.$static$=function(){C$.$static$=0;
{
try {
C$.macOffset=("Mac OS X".equals$O(System.getProperty$S("os.name"))) ? 16 : 0;
} catch (ex) {
if (Clazz.exceptionOf(ex,"SecurityException")){
} else {
throw ex;
}
}
};
};
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 10:48:29 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
