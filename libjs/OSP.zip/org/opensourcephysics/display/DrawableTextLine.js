(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),p$1={},I$=[[0,'org.opensourcephysics.display.DrawableTextLine','java.awt.Color','org.opensourcephysics.display.OSPRuntime','java.awt.geom.AffineTransform','java.awt.image.BufferedImage','java.awt.RenderingHints',['java.awt.geom.Point2D','.Double'],['org.opensourcephysics.display.DrawableTextLine','.DrawableTextLineLoader']]],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DrawableTextLine", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.display.TextLine', 'org.opensourcephysics.display.Drawable');
C$.$classes$=[['DrawableTextLineLoader',12]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.theta=0;
this.pixelXY=false;
},1);

C$.$fields$=[['Z',['pixelXY'],'D',['x','y','theta']]]

Clazz.newMeth(C$, 'c$$S$D$D', function (text, x, y) {
;C$.superclazz.c$$S.apply(this,[text]);C$.$init$.apply(this);
this.x=x;
this.y=y;
this.color=$I$(2).BLACK;
}, 1);

Clazz.newMeth(C$, 'setPixelXY$Z', function (enable) {
this.pixelXY=enable;
});

Clazz.newMeth(C$, 'setX$D', function (x) {
this.x=x;
});

Clazz.newMeth(C$, 'setTheta$D', function (theta) {
this.theta=theta;
});

Clazz.newMeth(C$, 'getX$', function () {
return this.x;
});

Clazz.newMeth(C$, 'setY$D', function (y) {
this.y=y;
});

Clazz.newMeth(C$, 'getY$', function () {
return this.y;
});

Clazz.newMeth(C$, 'draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (panel, g) {
if ((this.text == null ) || this.text.equals$O("") ) {
return;
}var oldFont=g.getFont$();
if (this.pixelXY) {
this.drawWithPix$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics(panel, g);
} else {
this.drawWithWorld$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics(panel, g);
}g.setFont$java_awt_Font(oldFont);
});

Clazz.newMeth(C$, 'drawWithPix$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (panel, g) {
if ($I$(3).isMac$()) {
p$1.drawWithPixMac$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics.apply(this, [panel, g]);
} else {
p$1.drawWithPixWindows$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics.apply(this, [panel, g]);
}});

Clazz.newMeth(C$, 'drawWithPixWindows$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (panel, g) {
if (this.theta != 0 ) {
(g).transform$java_awt_geom_AffineTransform($I$(4).getRotateInstance$D$D$D(-this.theta, this.x, this.y));
this.drawText$java_awt_Graphics$I$I(g, (this.x|0), (this.y|0));
(g).transform$java_awt_geom_AffineTransform($I$(4).getRotateInstance$D$D$D(this.theta, this.x, this.y));
} else {
this.drawText$java_awt_Graphics$I$I(g, (this.x|0), (this.y|0));
}}, p$1);

Clazz.newMeth(C$, 'drawWithPixMac$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (panel, g) {
if (this.theta == 0 ) {
p$1.drawWithPixWindows$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics.apply(this, [panel, g]);
return;
}var w=g.getFontMetrics$().stringWidth$S(this.text) + 7;
var h=g.getFontMetrics$().getHeight$() + 10;
var image=Clazz.new_($I$(5,1).c$$I$I$I,[w, h, 2]);
var imageGraphics=image.createGraphics$();
imageGraphics.setFont$java_awt_Font(g.getFont$());
imageGraphics.setColor$java_awt_Color($I$(2).BLACK);
this.drawText$java_awt_Graphics$I$I(imageGraphics, (w/2|0) - 2, h - 5);
imageGraphics.dispose$();
var g2d=g;
g2d.translate$D$D(this.x - h - 2 , this.y + (w/2|0));
var at=$I$(4).getRotateInstance$D$D$D(-this.theta, 0, 0);
g2d.setRenderingHint$java_awt_RenderingHints_Key$O($I$(6).KEY_INTERPOLATION, $I$(6).VALUE_INTERPOLATION_BICUBIC);
g2d.drawImage$java_awt_Image$java_awt_geom_AffineTransform$java_awt_image_ImageObserver(image, at, panel);
g2d.translate$D$D(-this.x + h + 2 , -this.y - (w/2|0));
}, p$1);

Clazz.newMeth(C$, 'drawWithWorld$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (panel, g) {
if ($I$(3).isMac$()) {
p$1.drawWithWorldMac$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics.apply(this, [panel, g]);
} else {
p$1.drawWithWorldWindows$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics.apply(this, [panel, g]);
}});

Clazz.newMeth(C$, 'drawWithWorldMac$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (panel, g) {
if (this.theta == 0 ) {
p$1.drawWithWorldWindows$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics.apply(this, [panel, g]);
return;
}var w=g.getFontMetrics$().stringWidth$S(this.text) + 7;
var h=g.getFontMetrics$().getHeight$() + 10;
var image=Clazz.new_($I$(5,1).c$$I$I$I,[w, h, 2]);
var imageGraphics=image.createGraphics$();
imageGraphics.setColor$java_awt_Color($I$(2).BLACK);
imageGraphics.setFont$java_awt_Font(g.getFont$());
this.drawText$java_awt_Graphics$I$I(imageGraphics, (w/2|0) - 2, h - 5);
imageGraphics.dispose$();
var g2d=g;
var pt=Clazz.new_($I$(7,1).c$$D$D,[this.x, this.y]);
pt=panel.getPixelTransform$().transform$java_awt_geom_Point2D$java_awt_geom_Point2D(pt, pt);
g2d.translate$D$D(pt.getX$() - h - 2 , pt.getY$() + (w/2|0));
var at=$I$(4).getRotateInstance$D$D$D(-this.theta, 0, 0);
g2d.setRenderingHint$java_awt_RenderingHints_Key$O($I$(6).KEY_INTERPOLATION, $I$(6).VALUE_INTERPOLATION_BICUBIC);
g2d.drawImage$java_awt_Image$java_awt_geom_AffineTransform$java_awt_image_ImageObserver(image, at, panel);
g2d.translate$D$D(-pt.getX$() + h + 2 , -pt.getY$() - (w/2|0));
}, p$1);

Clazz.newMeth(C$, 'drawWithWorldWindows$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (panel, g) {
var pt=Clazz.new_($I$(7,1).c$$D$D,[this.x, this.y]);
pt=panel.getPixelTransform$().transform$java_awt_geom_Point2D$java_awt_geom_Point2D(pt, pt);
if (this.theta != 0 ) {
(g).transform$java_awt_geom_AffineTransform($I$(4,"getRotateInstance$D$D$D",[-this.theta, pt.getX$(), pt.getY$()]));
this.drawText$java_awt_Graphics$I$I(g, (pt.getX$()|0), (pt.getY$()|0));
(g).transform$java_awt_geom_AffineTransform($I$(4,"getRotateInstance$D$D$D",[this.theta, pt.getX$(), pt.getY$()]));
} else {
this.drawText$java_awt_Graphics$I$I(g, (pt.getX$()|0), (pt.getY$()|0));
}}, p$1);

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(8,1));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.DrawableTextLine, "DrawableTextLineLoader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'org.opensourcephysics.controls.XMLLoader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var drawableTextLine=obj;
control.setValue$S$O("text", drawableTextLine.getText$());
control.setValue$S$D("x", drawableTextLine.x);
control.setValue$S$D("y", drawableTextLine.y);
control.setValue$S$D("theta", drawableTextLine.theta);
control.setValue$S$O("color", drawableTextLine.color);
control.setValue$S$Z("pixel position", drawableTextLine.pixelXY);
});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
return Clazz.new_($I$(1,1).c$$S$D$D,["", 0, 0]);
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var drawableTextLine=obj;
drawableTextLine.x=control.getDouble$S("x");
drawableTextLine.y=control.getDouble$S("y");
drawableTextLine.theta=control.getDouble$S("theta");
drawableTextLine.pixelXY=control.getBoolean$S("pixel position");
drawableTextLine.setText$S(control.getString$S("text"));
drawableTextLine.color=control.getObject$S("color");
return obj;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 10:48:28 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
