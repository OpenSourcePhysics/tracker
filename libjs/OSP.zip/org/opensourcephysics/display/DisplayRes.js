(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),I$=[[0,'java.util.ResourceBundle']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DisplayRes");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['S',['BUNDLE_NAME'],'O',['res','java.util.ResourceBundle']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'setLocale$java_util_Locale', function (locale) {
C$.res=$I$(1).getBundle$S$java_util_Locale(C$.BUNDLE_NAME, locale);
}, 1);

Clazz.newMeth(C$, 'getString$S', function (key) {
try {
return C$.res.getString$S(key);
} catch (e) {
if (Clazz.exceptionOf(e,"java.util.MissingResourceException")){
return '!' + key + '!' ;
} else {
throw e;
}
}
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.BUNDLE_NAME="org.opensourcephysics.resources.display.display_res";
C$.res=$I$(1).getBundle$S(C$.BUNDLE_NAME);
};
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 10:48:28 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
