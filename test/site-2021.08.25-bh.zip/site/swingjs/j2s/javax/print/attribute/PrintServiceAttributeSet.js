(function(){var P$=Clazz.newPackage("javax.print.attribute"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "PrintServiceAttributeSet", null, null, 'javax.print.attribute.AttributeSet');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.3.1-v1');//Created 2021-07-22 00:09:29 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
