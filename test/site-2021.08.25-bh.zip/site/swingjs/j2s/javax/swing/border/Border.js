(function(){var P$=Clazz.newPackage("javax.swing.border"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Border");
})();
;Clazz.setTVer('3.3.1-v1');//Created 2021-07-22 00:09:41 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
